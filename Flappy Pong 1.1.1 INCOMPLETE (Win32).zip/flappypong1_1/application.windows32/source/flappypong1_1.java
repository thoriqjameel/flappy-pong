import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class flappypong1_1 extends PApplet {

/******* VARIABLES *********/

// We control which screen is active by settings / updating
// gameScreen variable. We display the correct screen according
// to the value of this variable.
// 
// 0: Initial Screen
// 1: Game Screen
// 2: Game-over Screen 

int gameScreen = 0;

// gameplay settings
float gravity = 0.3f;
float airfriction = 0.00001f;
float friction = 0.1f;

// scoring

int score = 0;
float maxHealth = 255;
float health = 255;
int drawmaxHealth = 255;
int drawhealth = 255;
int healthDecrease = 1;
int healthBarWidth = 255;
int points = 0;
float index = 0;
float toPerf = 0;

// draw HP
public void drawhp (){

}
// ball settings
float ballX, ballY;
float ballSpeedVert = 0;
float ballSpeedHorizon = 0;
float ballSize = 20;
int ballColor = color(0);

// racket settings
int racketColor = color(0, 255, health);
float racketWidth = 100;
float racketHeight = 10;

// wall settings
int wallSpeed = 5;
int wallInterval = 1000;
float lastAddTime = 0;
int minGapHeight = 200;
int maxGapHeight = 300;
int wallWidth = 80;
int wallColors = color(random(44, 88), random(62, 124), random(80, 160));
// This arraylist stores data of the gaps between the walls. Actuals walls are drawn accordingly.
// [gapWallX, gapWallY, gapWallWidth, gapWallHeight, scored]
ArrayList<int[]> walls = new ArrayList<int[]>();

/******* SETUP BLOCK *********/

public void setup() {
  frameRate(300);
  
  // set the initial coordinates of the ball
  ballX=width/4;
  ballY=height/5;
  
}


/******* DRAW BLOCK *********/

public void draw() {
  // Display the contents of the current screen
  if (gameScreen == 0) { 
    initScreen();
  } else if (gameScreen == 1) { 
    gameScreen();
  } else if (gameScreen == 2) { 
    gameOverScreen();
  }
}


/******* SCREEN CONTENTS *********/

public void initScreen() {
  background(236, 240, 241);
  textAlign(CENTER);
  fill(52, 73, 94);
  textSize(35);
  text("Latest Score: " + score, width/2, height/2 - 120);
  text("Latest Points: " + points, width/2, height/2 - 155);
  textSize(70);
  text("Flappy Pong", width/2, height/2);
  textSize(15); 
  text("Click to start", width/2, height-30);
  textSize(40);
  fill(255, 191, 0);
  text("Perfection(Latest Game): " + toPerf, width/2, height/2 - 195);
  
}
public void gameScreen() {
  int framePerSec = round(frameRate);
  background(236, 240, 241);
  drawRacket();
  watchRacketBounce();
  drawBall();
  applyGravity();
  applyHorizontalSpeed();
  keepInScreen();
  drawHealthBar();
  printScore();
  wallAdder();
  wallHandler();
  drawHealthText();
  printPointsonBoard();
  textAlign(LEFT);
  textSize(15);
  fill(0);
  text(framePerSec + " FPS",0,15);
  fill(255,framePerSec * 3,0,127);
  rect(0, 15, frameRate * 10, 15);
}
public void gameOverScreen() {
  background(44, 62, 80);
  textAlign(CENTER);
  fill(236, 240, 241);
  textSize(40);
  text("Your Score + Your Points", width/2, height/2 - 120);
  textSize(60);
  text(score + "\n" + points, width/2, height/2);
  textSize(15);
  text("Click to Restart", width/2, height-30);
}


/******* INPUTS *********/

public void mousePressed() {
  // if we are on the initial screen when clicked, start the game 
  if (gameScreen==0) { 
    startGame();
    score = 0;
    points = points / round(random(2, 90));
  }
  if (gameScreen==2) {
    restart();
    index = points / 20000;
    toPerf = index * 100 / score;
  }
}



/******* OTHER FUNCTIONS *********/

// This method sets the necessery variables to start the game  
public void startGame() {
  gameScreen=1;
  score = 0;
  health = 255;
  maxHealth = 255;
  drawhealth = 255;
  drawmaxHealth = 255;
  
}
public void gameOver() {
  gameScreen=2;
}

public void restart() {
 
  
  health = maxHealth;
  ballX=width/4;
  ballY=height/5;
  lastAddTime = 0;
  walls.clear();
  gameScreen = 0;
}

public void drawBall() {
  fill(health, health, 255);
  ellipse(ballX, ballY, ballSize, ballSize);
  
}
public void drawRacket() {
  fill(0, 0, 255);
  rectMode(CENTER);
  rect(mouseX, mouseY, racketWidth, racketHeight, 5);
}

public void wallAdder() {
  if (millis()-lastAddTime > wallInterval) {
    int randHeight = round(random(minGapHeight, maxGapHeight));
    int randY = round(random(0, height-randHeight));
    // {gapWallX, gapWallY, gapWallWidth, gapWallHeight, scored}
    int[] randWall = {width, randY, wallWidth, randHeight, 0}; 
    walls.add(randWall);
    lastAddTime = millis();
  }
}
public void wallHandler() {
  for (int i = 0; i < walls.size(); i++) {
    wallRemover(i);
    wallMover(i);
    wallDrawer(i);
    watchWallCollision(i);
  }
}
public void wallDrawer(int index) {
  int[] wall = walls.get(index);
  // get gap wall settings 
  int gapWallX = wall[0];
  int gapWallY = wall[1];
  int gapWallWidth = wall[2];
  int gapWallHeight = wall[3];
  // draw actual walls
  rectMode(CORNER);
  noStroke();
  strokeCap(ROUND);
  fill(wallColors);
  rect(gapWallX, 0, gapWallWidth, gapWallY, 0, 0, 15, 15);
  rect(gapWallX, gapWallY+gapWallHeight, gapWallWidth, height-(gapWallY+gapWallHeight), 15, 15, 0, 0);
}
public void wallMover(int index) {
  int[] wall = walls.get(index);
  wall[0] -= wallSpeed;
}
public void wallRemover(int index) {
  int[] wall = walls.get(index);
  if (wall[0]+wall[2] <= 0) {
    walls.remove(index);
  }
}

public void watchWallCollision(int index) {
  int[] wall = walls.get(index);
  // get gap wall settings 
  int gapWallX = wall[0];
  int gapWallY = wall[1];
  int gapWallWidth = wall[2];
  int gapWallHeight = wall[3];
  int wallScored = wall[4];
  int wallTopX = gapWallX;
  int wallTopY = 0;
  int wallTopWidth = gapWallWidth;
  int wallTopHeight = gapWallY;
  int wallBottomX = gapWallX;
  int wallBottomY = gapWallY+gapWallHeight;
  int wallBottomWidth = gapWallWidth;
  int wallBottomHeight = height-(gapWallY+gapWallHeight);

  if (
    (ballX+(ballSize/2)>wallTopX) &&
    (ballX-(ballSize/2)<wallTopX+wallTopWidth) &&
    (ballY+(ballSize/2)>wallTopY) &&
    (ballY-(ballSize/2)<wallTopY+wallTopHeight)
    ) {
    decreaseHealth();
  }
  if (
    (ballX+(ballSize/2)>wallBottomX) &&
    (ballX-(ballSize/2)<wallBottomX+wallBottomWidth) &&
    (ballY+(ballSize/2)>wallBottomY) &&
    (ballY-(ballSize/2)<wallBottomY+wallBottomHeight)
    ) {
    decreaseHealth();
  }

  if (ballX > gapWallX+(gapWallWidth/2) && wallScored==0) {
    wallScored=1;
    wall[4]=1;
    score();
     }
  }





public void drawHealthBar() {
  noStroke();
  fill(189, 195, 199);
  rectMode(CORNER);
  rect(ballX-(healthBarWidth/2), ballY - 30, healthBarWidth, 5);
  if (health > 150) {
    fill(46, 204, 113);
  } else if (health > 70) {
    fill(230, 126, 34);
  } else {
    fill(231, 76, 60);
  }
  rectMode(CORNER);
  rect(ballX-(healthBarWidth/2), ballY - 30, healthBarWidth*(health/maxHealth), 5);
}
public void drawHealthText()
{
  fill(0);
  textAlign(TOP);
  textSize(20);
  text(drawhealth + "/" + drawmaxHealth, ballX-(healthBarWidth-5), ballY - 30);
  
}
public void decreaseHealth() {
  health -= healthDecrease;
  points += round(random(1, 2));
  drawhealth -= healthDecrease;
  if (health <= 0) {
    gameOver();
  }
}
public void score() {
  score++;
  health += 2;
  maxHealth += 2;
  drawhealth += 2;
  drawmaxHealth += 2;
 points += round(random(10000,20000));
  
}
public void printScore() {
  textAlign(CENTER);
  fill(0);
  textSize(30); 
  text(score, height/2, 50);
}
public void printPointsonBoard() {
  textAlign(CENTER);
  fill(212,175,55);
  textSize(30); 
  text(points, height/2, 90);
}

public void watchRacketBounce() {
  float overhead = mouseY - pmouseY;
  if ((ballX+(ballSize/2) > mouseX-(racketWidth/2)) && (ballX-(ballSize/2) < mouseX+(racketWidth/2))) {
    if (dist(ballX, ballY, ballX, mouseY)<=(ballSize/2)+abs(overhead)) {
      makeBounceBottom(mouseY);
      ballSpeedHorizon = (ballX - mouseX)/10;
      // racket moving up
      if (overhead<0) {
        ballY+=(overhead/2);
        ballSpeedVert+=(overhead/2);
      }
    }
  }
}
public void applyGravity() {
  ballSpeedVert += gravity;
  ballY += ballSpeedVert;
  ballSpeedVert -= (ballSpeedVert * airfriction);
}
public void applyHorizontalSpeed() {
  ballX += ballSpeedHorizon;
  ballSpeedHorizon -= (ballSpeedHorizon * airfriction);
}
// ball falls and hits the floor (or other surface) 
public void makeBounceBottom(float surface) {
  ballY = surface-(ballSize/2);
  ballSpeedVert*=-1;
  ballSpeedVert -= (ballSpeedVert * friction);
}
// ball rises and hits the ceiling (or other surface)
public void makeBounceTop(float surface) {
  ballY = surface+(ballSize/2);
  ballSpeedVert*=-1;
  ballSpeedVert -= (ballSpeedVert * friction);
}
// ball hits object from left side
public void makeBounceLeft(float surface) {
  ballX = surface+(ballSize/2);
  ballSpeedHorizon*=-1;
  ballSpeedHorizon -= (ballSpeedHorizon * friction);
}
// ball hits object from right side
public void makeBounceRight(float surface) {
  ballX = surface-(ballSize/2);
  ballSpeedHorizon*=-1;
  ballSpeedHorizon -= (ballSpeedHorizon * friction);
}
// keep ball in the screen
public void keepInScreen() {
  // ball hits ground
  if (ballY+(ballSize/2) > height) { 
    makeBounceBottom(height);
  }
  // ball hits ceiling
  if (ballY-(ballSize/2) < 0) {
    makeBounceTop(0);
  }
  // ball hits left of the screen
  if (ballX-(ballSize/2) < 0) {
    makeBounceLeft(0);
  }
  // ball hits right of the screen
  if (ballX+(ballSize/2) > width) {
    makeBounceRight(width);
  }
}
/* CHANGELOG
   Version 1.0   
   After I *copied* the Flappy Pong source code
   Version 1.0.1
   Added HP functions(HP and Max HP get added by 2 every time you get a point)
   Version 1.1.0(Current)
   Added points, FPS Counter, FPS cap(300 FPS)*/
  // --WARNING-- \\
  
     // This only(probably) works on Processing 3, the Processing version I coded this with...
     
     
     
/* Check README for Recommended GPU / CPU
 Recommended
 GPU
 Intel(R) HD Graphics 515
 CPU
 Intel(R) Core(TM) m3-6Y30 CPU @ 900 MHz */
  public void settings() {  size(1920,1280);  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "flappypong1_1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
